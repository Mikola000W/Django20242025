from django import forms
from django.forms import ModelForm
from .models import Ogloszenia,Uzytkownik

class OglForm(ModelForm):
    class Meta:
        model = Ogloszenia
        exclude=[]
        labels={
            'uzytkownik_id':"Wybierz użytkownika"
        }

class UzytkForm(ModelForm):
    class Meta:
        model=Uzytkownik
        exclude=[]
        widgets={
            'nazwisko':forms.PasswordInput()
        }
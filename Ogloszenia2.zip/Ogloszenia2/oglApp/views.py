from django.shortcuts import render, get_object_or_404,redirect
from oglApp.models import Uzytkownik,Ogloszenia
from .forms import OglForm, UzytkForm
from django.contrib.auth.decorators import login_required
def indeks(request):
    ogloszenia = Ogloszenia.objects.all()
    return render(request, 'index.html', {'ogloszenia':ogloszenia})

def tresc(request,id):
    pobieranie = Ogloszenia.objects.get(pk=id)
    if request.method == 'POST':
        pobieranie.delete()
        return redirect('/')
    return render(request, 'tresc.html',{'pobieranie':pobieranie})
def uzytkownik(request):
    uzytkownik = Uzytkownik.objects.all()
    return render(request,'uzytkownik.html', {'uzytkownik':uzytkownik})

def ksiazka(request):
    ksiazka = Ogloszenia.objects.filter(kategoria=1)
    return render(request, 'ksiazka.html', {'ksiazka':ksiazka})
@login_required
def new(request):

    if request.method == 'POST':
        form = UzytkForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('uzytkownik')
    else:
        form = UzytkForm()

    return render(request, "new.html", {'form': form})
@login_required
def nowe(request):

    if request.method == 'POST':
        forms = OglForm(request.POST)
        if forms.is_valid():
            forms.save()
            return redirect('/')
    else:
        forms = OglForm()

    return render(request, 'noweogloszenie.html',{'forms' : forms})

from django.db import models
from django import forms

class Uzytkownik(models.Model):
    imie = models.CharField(max_length=100)
    nazwisko = models.CharField(max_length=100)
    telefon = models.PositiveIntegerField()
    email = models.EmailField(max_length=200)

    def __str__(self):
        return f"{self.imie},{self.nazwisko}"
    class Meta:
        verbose_name_plural = "Użytkownik"


class Ogloszenia(models.Model):
    kategoria = models.PositiveSmallIntegerField()
    podkategoria = models.PositiveSmallIntegerField()
    tytul = models.CharField(max_length=100)
    tresc = models.CharField(max_length=100)
    uzytkownik_id = models.ForeignKey(Uzytkownik, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.tytul},{self.kategoria}"

    class Meta:
        verbose_name_plural = "Ogłoszenia"
from django.forms import modelform_factory
from django.shortcuts import render, redirect
from pogotowieapp.models import *

forms = modelform_factory(Zgloszenia,exclude=[])
def pogotowie(request):
    zgl = Zgloszenia.objects.all()
    if request.method == 'POST':
        form = forms(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")
    else:
        form = forms()


    return render(request, 'pogotowie.html',{'zgl':zgl,'form':form})
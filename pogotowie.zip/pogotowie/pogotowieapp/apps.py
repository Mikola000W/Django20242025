from django.apps import AppConfig


class PogotowieappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pogotowieapp'
